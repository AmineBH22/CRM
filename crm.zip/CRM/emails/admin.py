from django.contrib import admin

from emails.models import Email

# Register your models here.
admin.site.register(Email)
