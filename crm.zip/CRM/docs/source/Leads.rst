Leads
*****



|  **Fig** Accounts Home Page

|  This is Account Home Page, this page gives details and list view of leads
|  You can filter the results by name, source, assigned user, status, tags

|  Create a new Lead using the button on right corner ``+ Add New Lead``


|  **Fig** Leads Create Page

|  **Note:** Fields having ``*`` are mandatory
